#ifndef _LIBBALANCEWORKS_H_
#define _LIBBALANCEWORKS_H_

void loop_balanceWorks(int x_len, int y_len);

#endif  // _LIBBALANCEWORKS_H_
