#ifndef _LIBCOPWORKS_H_
#define _LIBCOPWORKS_H_

void setup_fsrled();

int cop_led_x = 0;
int cop_led_y = 0;
int cop_led_value = 0;

void loop_fsrled(int range_width, int range_height);

void find_COP(int range_width, int range_height);

void COP_fifo_in(int x, int y, int strenth);

void fill_COP100();

#endif  // _LIBCOPWORKS_H_