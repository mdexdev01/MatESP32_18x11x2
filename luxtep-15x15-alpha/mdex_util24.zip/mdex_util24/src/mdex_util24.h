#ifndef MDEXUTIL24_H_
#define MDEXUTIL24_H_

class MDEX_Util24{
public:
    static int conv_1515a(int adc_val, int cut_off, int range_end, int option);
    static int value_conv(int number);
    static int values_conv(unsigned char * data, int data_len);
};

#endif