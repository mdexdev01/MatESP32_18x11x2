#ifndef MDEXUTIL24_H_
#define MDEXUTIL24_H_

class MDEX_Util24{
public:
    MDEX_Util24() {};
    ~MDEX_Util24() {};
    static int conv_1515a(int adc_val, int cut_off, int range_end, int option);
    int value_conv(int number);
    int values_conv(unsigned char * data, int data_len);
};

#endif