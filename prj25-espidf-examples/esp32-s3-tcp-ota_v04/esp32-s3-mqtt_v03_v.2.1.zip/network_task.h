// network_task.h
// Version: Ver.1.1 (Final Naming)
// Author: mdex.co.kr
// Date: 2025-07-22
// 역할: 모든 모듈을 조율하고 프로그램의 실질적인 흐름을 관리합니다.

#ifndef _NETWORK_TASK_H_
#define _NETWORK_TASK_H_

// --- 표준 및 외부 라이브러리 ---
#include <WiFi.h>
#include <PubSubClient.h>
#include "time.h"

// --- 커스텀 라이브러리 ---
#include "network_info.h"
#include "libPrintRaw.h"
#include "lib_nvs.h"
#include "lib_wifi.h"
#include "lib_softAP.h"
#include "lib_hiveMqtt.h"
#include "lib_tcpClient.h"



// ====================================================================
// --- 전역 변수 정의 (조율자 소유) ---
// ====================================================================
const char* ntpServer = "pool.ntp.org";
String mqttClientId;
String myFormattedMacAddress;
String currentAppID;
String receivedTcpServerIpAddress;
String storedTcpServerIp;
unsigned long bootTimestamp = 0;
String serialCommand = "";


// ====================================================================
// --- Extern 객체 선언 ---
// ====================================================================
extern PubSubClient client;
extern bool shouldEnterSoftAP;
extern WiFiClient tcpClient;


// ====================================================================
// --- 초기화 총괄 함수 ---
// ====================================================================
void setup_wifi_and_nvs() {
    WiFi.onEvent(WiFiEvent);
    if (!connectToWiFiFromNVS()) {
        setup_config_mode();
        uart0_printf("[%8lu ms] [Setup] Entered SoftAP Configuration Mode.\n", millis());
    } else {
        prefs.begin(NVS_NAMESPACE, true);
        currentAppID = prefs.getString(NVS_KEY_APPID, DEFAULT_APPID);
        prefs.end();
        uart0_printf("[%8lu ms] [Setup] Loaded AppID: %s\n", millis(), currentAppID.c_str());
        storedTcpServerIp = loadTcpIpFromNVS();
    }
}

void setup_mqtt_client() {
    if (root_ca == nullptr || root_ca[0] == '\0') {
        uart0_printf("[%8lu ms] [ERROR] Root CA certificate is empty or invalid!\n", millis());
    }
    clientSecure.setCACert(root_ca);
    client.setServer(MQTT_BROKER, MQTT_PORT);
    client.setCallback(callback);
}

void setup_tcp_client_task() {
    void tcpReceiverTask(void* param);
    xTaskCreatePinnedToCore(tcpReceiverTask, "TCP_RX_Task", 4096, NULL, 1, NULL, 1);
}

// ====================================================================
// --- 시리얼 명령 처리 함수 ---
// ====================================================================
void handleSerialCommand() {
    while (Serial.available()) {
        char inChar = (char)Serial.read();
        serialCommand += inChar;
        if (inChar == '\n' || inChar == '\r') {
            serialCommand.trim();
            serialCommand.toLowerCase();
            if (serialCommand.equals("delete nvs")) {
                prefs.begin(NVS_NAMESPACE, false);
                prefs.clear();
                prefs.end();
                ESP.restart();
            }
            serialCommand = "";
        }
    }
}

// ====================================================================
// --- 메인 Setup 및 Loop 함수 (실질적인 로직) ---
// ====================================================================
void setup_network_tasks() {
    Serial.begin(SERIAL_BAUDRATE);
    delay(100);
    uart0_printf("[%8lu ms] --- ESP32-S3 MQTT/TCP Client (v2.2) ---\n", millis());

    bootTimestamp = millis();

    setup_wifi_and_nvs();
    // WiFi가 성공적으로 연결된 후에만 아래 로직 실행
    if (WiFi.status() == WL_CONNECTED) {
        // --- NTP 시간 동기화 코드 (시작) ---
        uart0_printf("Configuring time from NTP server...\n");
        configTime(9 * 3600, 0, ntpServer); // GMT+9 (한국 시간), 썸머타임 없음
        
        struct tm timeinfo;
        if (!getLocalTime(&timeinfo)) {
            uart0_printf("Failed to obtain time\n");
        } else {
            uart0_printf("Time synchronized: %s", asctime(&timeinfo));
        }
        // --- NTP 시간 동기화 코드 (끝) ---

        setup_mqtt_client();
        setup_tcp_client_task();
    }

    uart0_printf("[%8lu ms] [Setup] Main setup complete.\n", millis());
}

void loop_network_tasks() {
    handleSerialCommand();

    if (shouldEnterSoftAP) {
        loop_config_mode();
    } else {
        loop_checkSafeTCP(); // WiFi, MQTT, TCP 연결 관리

        if (tcpClient.connected()) {
            static unsigned long lastTcpSendAttempt_loop = 0;
            if (tcpSendInterval <= millis() - lastTcpSendAttempt_loop) {
                createAndSendTcpPacket();
                lastTcpSendAttempt_loop = millis();
            }
        }
    }
    delay(10);
}


#endif // _NETWORK_TASK_H_