// lib_tcpClient.h
// Version: Ver.1.13 (Fix Packet_SIZE in createAndSendTcpPacket)
// File: lib_tcpClient.h
// Author: Original Author
// Date: 2025-07-15 (Current Date)

#ifndef _LIB_TCPCLIENT_H_
#define _LIB_TCPCLIENT_H_

#include <WiFi.h>
#include <WiFiClient.h>
#include "libPrintRaw.h"
#include "login_info.h"

extern WiFiClient tcpClient;
extern String receivedTcpServerIpAddress;
extern String currentAppID;

const int TCP_PACKET_SIZE = 998 + 952; // PC에서 온 lib_tcpStar.h의 PACKET_SIZE를 가져옴
unsigned long lastTcpSendAttempt = 0;
const unsigned long tcpSendInterval = 10; // 10ms (100 FPS)

unsigned long lastTcpConnectAttempt = 0;
const unsigned long tcpConnectInterval = 5000;

void setup_tcp_client_module();
void connectToTcpServer();
void createAndSendTcpPacket();
void tcpReceiverTask(void* param);

void setup_tcp_client_module() {
  xTaskCreatePinnedToCore(tcpReceiverTask, "TCP_RX_Task", 4096, NULL, 1, NULL, 1);
  uart0_printf("[%8lu ms] [Setup] TCP Receiver Task created.\n", millis());
}

void connectToTcpServer() {
  if (receivedTcpServerIpAddress.length() == 0) {
    uart0_printf("[%8lu ms] [TCP Client] No App server IP received yet.\n", millis());
    return;
  }
  if (!tcpClient.connected()) {
    uart0_printf("[%8lu ms] [TCP Client] Attempting to connect to App server: %s:%d...\n", millis(), receivedTcpServerIpAddress.c_str(), TCP_SERVER_PORT);
    if (tcpClient.connect(receivedTcpServerIpAddress.c_str(), TCP_SERVER_PORT)) {
      uart0_printf("[%8lu ms] [TCP Client] Connected to App server.\n", millis());
    } else {
      uart0_printf("[%8lu ms] [TCP Client] Connection to App server failed.\n", millis());
    }
  }
}

void createAndSendTcpPacket() {
  static uint32_t sequenceNumber = 0;
  static uint8_t txBuffer[TCP_PACKET_SIZE];

  txBuffer[0] = (byte)0xFF;
  txBuffer[1] = (byte)0xFF;
  txBuffer[2] = 0x02;
  txBuffer[3] = (currentAppID.length() > 0) ? (currentAppID.charAt(currentAppID.length() - 1) - '0') : 0; 
  txBuffer[3] = 1;

  memset(txBuffer + 8, txBuffer[3], TCP_PACKET_SIZE - 9);

  txBuffer[TCP_PACKET_SIZE - 2] = sequenceNumber % 100; // <-- PACKET_SIZE -> TCP_PACKET_SIZE
  txBuffer[TCP_PACKET_SIZE - 1] = (byte)0xFE;         // <-- PACKET_SIZE -> TCP_PACKET_SIZE

  if (tcpClient.connected()) {
    tcpClient.write(txBuffer, TCP_PACKET_SIZE);
    if(sequenceNumber % 100 == 0)
      uart0_printf("[%8lu ms] [TCP Client] Sent packet seq=%lu\n", millis(), sequenceNumber);
  }
  sequenceNumber++;
}

void tcpReceiverTask(void* param) {
  const int PACKET_SIZE_TCP_RX = TCP_PACKET_SIZE;
  static uint8_t rxBuf[PACKET_SIZE_TCP_RX];

  while (true) {
    if (tcpClient.connected() && tcpClient.available() >= PACKET_SIZE_TCP_RX) {
      tcpClient.read(rxBuf, PACKET_SIZE_TCP_RX);

      if (rxBuf[0] == 0xFF && rxBuf[1] == 0xFF && rxBuf[PACKET_SIZE_TCP_RX - 1] == 0xFE) {
        uint8_t seq = rxBuf[PACKET_SIZE_TCP_RX - 2];
        if(millis() % 1000 < 10) // 로그 빈도 감소: 대략 초당 한 번만 로그 (예시)
            uart0_printf("[%8lu ms] [TCP Client] Packet received from App server | seq: %d\n", millis(), seq);
      } else {
        uart0_printf("[%8lu ms] [TCP Client] Received malformed packet from App server.\n", millis());
      }
    }
    delay(1);
  }
}

#endif // _LIB_TCPCLIENT_H_