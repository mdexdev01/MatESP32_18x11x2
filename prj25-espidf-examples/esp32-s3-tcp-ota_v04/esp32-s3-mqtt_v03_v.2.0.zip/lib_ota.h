// lib_ota.h
// Version: Ver.1.14 (Fix Undefined References - Variables Definition) // 버전 업데이트
// File: lib_ota.h
// Author: Original Author
// Date: 2025-07-15 (Current Date)

#ifndef _LIB_OTA_H_
#define _LIB_OTA_H_

#include <WiFi.h>        // WiFi 클래스 사용
#include <WebServer.h>   // WebServer 클래스 사용
#include <Preferences.h> // NVS (Non-Volatile Storage) 사용
#include "libPrintRaw.h" // uart0_printf 사용

// --- 전역 변수 정의 (extern 제거하여 여기서 정의되도록 함) ---
Preferences prefs; // extern 제거
WebServer server(80); // extern 제거
bool shouldEnterSoftAP = false; // extern 제거

// --- 상수 정의 ---
const char* ap_ssid = "LUXTEP_MAT_CONFIG"; // SoftAP SSID 변경
const char* ap_password = "password"; // SoftAP 비밀번호 (설정용)

// NVS 키 정의
const char* NVS_NAMESPACE = "wifi_config";
const char* NVS_KEY_SSID = "ssid";
const char* NVS_KEY_PASS = "password";
const char* NVS_KEY_APPID = "app_id";
const char* NVS_KEY_TCP_IP = "tcp_ip"; // 추가: TCP 서버 IP를 위한 NVS 키

// 기본값
const char* DEFAULT_SSID = "KT_GiGA_2G_Wave2_4587";
const char* DEFAULT_PASSWORD = "fab8ezx455";
const char* DEFAULT_APPID = "banana7";

// --- 함수 선언 ---
bool isSSID2_4GHz(const char* target_ssid);
void handleRoot();
void handleSave();
void startSoftAP();
bool connectToWiFiFromNVS(); // NVS에서 읽어와 WiFi 연결 시도
void setup_config_mode(); // 설정 모드 (SoftAP) 초기화
void loop_config_mode(); // 설정 모드 루프

// NVS에 TCP 서버 IP를 저장하는 함수
void saveTcpIpToNVS(const String& ip);
// NVS에서 TCP 서버 IP를 읽어오는 함수
String loadTcpIpFromNVS();

// --- 함수 구현 ---

// --- WiFi SSID가 2.4GHz 대역인지 확인하는 함수 ---
bool isSSID2_4GHz(const char* target_ssid) {
  int n = WiFi.scanNetworks();
  if (n == 0) {
    uart0_printf("[%8lu ms] [WiFi Scan] No networks found.\n", millis());
    return false;
  }
  for (int i = 0; i < n; ++i) {
    String foundSSID = WiFi.SSID(i);
    if (foundSSID == target_ssid) {
      int channel = WiFi.channel(i); // 채널 번호로 대역 판별
      if (channel >= 1 && channel <= 14) {
        uart0_printf("[%8lu ms] [WiFi Scan] %s is 2.4GHz (Channel %d)\n", millis(), target_ssid, channel);
        return true; // 2.4GHz
      } else {
        uart0_printf("[%8lu ms] [WiFi Scan] %s is 5.0GHz (Channel %d) - ESP32 cannot connect.\n", millis(), target_ssid, channel);
        return false; // 5GHz (ESP32에서는 붙을 수 없음)
      }
    }
  }
  uart0_printf("[%8lu ms] [WiFi Scan] SSID '%s' not found in scan results.\n", millis(), target_ssid);
  return false; // SSID not found
}

// --- SoftAP 웹 서버 핸들러 ---
void handleRoot() {
  String html = R"rawliteral(
    <!DOCTYPE html>
    <html>
    <head>
      <title>ESP32 WiFi Config</title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <style>
        body { font-family: Arial, sans-serif; margin: 20px; background-color: #333; color: #eee; }
        .container { background-color: #555; padding: 20px; border-radius: 8px; max-width: 400px; margin: auto; }
        input[type="text"], input[type="password"] {
          width: calc(100% - 20px); padding: 10px; margin: 8px 0; border: 1px solid #777; border-radius: 4px;
          box-sizing: border-box; background-color: #444; color: #eee;
        }
        input[type="submit"] {
          width: 100%; background-color: #4CAF50; color: white; padding: 14px 20px; margin: 8px 0;
          border: none; border-radius: 4px; cursor: pointer; font-size: 16px;
        }
        input[type="submit"]:hover { background-color: #45a049; }
        label { display: block; margin-bottom: 5px; color: #ccc; }
      </style>
    </head>
    <body>
      <div class="container">
        <h2>ESP32 WiFi & AppID Configuration</h2>
        <form action="/save" method="POST">
          <label for="ssid">WiFi SSID:</label>
          <input type="text" id="ssid" name="ssid" value="%SSID_VALUE%"><br>
          <label for="password">WiFi Password:</label>
          <input type="password" id="password" name="password" value="%PASS_VALUE%"><br>
          <label for="app_id">AppID:</label>
          <input type="text" id="app_id" name="app_id" value="%APPID_VALUE%"><br>
          <input type="submit" value="Save & Connect">
        </form>
      </div>
    </body>
    </html>
  )rawliteral";

  // NVS에서 현재 저장된 값 읽어와서 초기값으로 채우기
  prefs.begin(NVS_NAMESPACE, true); // Read-only mode
  String current_ssid = prefs.getString(NVS_KEY_SSID, DEFAULT_SSID);
  String current_pass = prefs.getString(NVS_KEY_PASS, DEFAULT_PASSWORD);
  String current_app_id = prefs.getString(NVS_KEY_APPID, DEFAULT_APPID);
  prefs.end();

  html.replace("%SSID_VALUE%", current_ssid);
  html.replace("%PASS_VALUE%", current_pass);
  html.replace("%APPID_VALUE%", current_app_id);

  server.send(200, "text/html", html);
}

void handleSave() {
  String ssid_str = server.arg("ssid");
  String password_str = server.arg("password");
  String app_id_str = server.arg("app_id");

  uart0_printf("[%8lu ms] [Config] Received SSID: %s, AppID: %s\n", millis(), ssid_str.c_str(), app_id_str.c_str());

  prefs.begin(NVS_NAMESPACE, false); // Read-write mode
  prefs.putString(NVS_KEY_SSID, ssid_str);
  prefs.putString(NVS_KEY_PASS, password_str);
  prefs.putString(NVS_KEY_APPID, app_id_str);
  prefs.end();

  server.send(200, "text/html", "Saved. ESP32 will attempt to connect to WiFi. Rebooting...");
  uart0_printf("[%8lu ms] [Config] Configuration saved. Rebooting ESP32...\n", millis());
  delay(1000); // 클라이언트가 응답을 받을 시간
  ESP.restart(); // 설정 저장 후 재시작
}

// --- SoftAP 모드 시작 ---
void startSoftAP() {
  uart0_printf("[%8lu ms] [SoftAP] Starting SoftAP '%s'...\n", millis(), ap_ssid);
  WiFi.softAP(ap_ssid, ap_password);
  IPAddress IP = WiFi.softAPIP();
  uart0_printf("[%8lu ms] [SoftAP] AP IP: %s\n", millis(), IP.toString().c_str());

  server.on("/", HTTP_GET, handleRoot);
  server.on("/save", HTTP_POST, handleSave);
  server.begin();
  uart0_printf("[%8lu ms] [SoftAP] Web server started.\n", millis());
}

// --- NVS에서 WiFi 정보 읽어와 연결 시도 ---
bool connectToWiFiFromNVS() {
  prefs.begin(NVS_NAMESPACE, true); // Read-only mode
  String stored_ssid = prefs.getString(NVS_KEY_SSID, "");
  String stored_pass = prefs.getString(NVS_KEY_PASS, "");
  String stored_app_id = prefs.getString(NVS_KEY_APPID, ""); // AppID도 함께 읽음
  prefs.end();

  // NVS에서 읽어온 설정 정보 로그 추가
  uart0_printf("[%8lu ms] [NVS] Loaded config - SSID: '%s', AppID: '%s'\n", millis(), stored_ssid.c_str(), stored_app_id.c_str());
  // 민감한 정보이므로, 비밀번호는 로깅하지 않음.

  if (stored_ssid.length() == 0) {
    uart0_printf("[%8lu ms] [WiFi] No stored WiFi credentials. Entering SoftAP mode.\n", millis());
    shouldEnterSoftAP = true;
    return false;
  }

  uart0_printf("[%8lu ms] [WiFi] Attempting to connect to stored WiFi: %s\n", millis(), stored_ssid.c_str());
  
  // 2.4GHz 대역 확인
  if (!isSSID2_4GHz(stored_ssid.c_str())) {
    uart0_printf("[%8lu ms] [WiFi] Stored SSID '%s' is not 2.4GHz or not found. Entering SoftAP mode.\n", millis(), stored_ssid.c_str());
    shouldEnterSoftAP = true;
    return false;
  }

  WiFi.begin(stored_ssid.c_str(), stored_pass.c_str());

  unsigned long startAttemptTime = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - startAttemptTime < 15000) { // 15초 타임아웃
    delay(500);
    uart0_printf("[%8lu ms] [WiFi] Connecting... Status: %d\n", millis(), WiFi.status());
  }

  if (WiFi.status() == WL_CONNECTED) {
    uart0_printf("[%8lu ms] [OK] WiFi connected!, IP: %s\n", millis(), WiFi.localIP().toString().c_str());
    return true;
  } else {
    uart0_printf("[%8lu ms] [WiFi] Failed to connect to %s. Status: %d. Entering SoftAP mode.\n", millis(), stored_ssid.c_str(), WiFi.status());
    shouldEnterSoftAP = true;
    return false;
  }
}

// --- NVS에 TCP 서버 IP를 저장하는 함수 ---
void saveTcpIpToNVS(const String& ip) {
  prefs.begin(NVS_NAMESPACE, false); // Read-write mode
  prefs.putString(NVS_KEY_TCP_IP, ip);
  prefs.end();
  uart0_printf("[%8lu ms] [NVS] Saved TCP Server IP: %s\n", millis(), ip.c_str());
}

// --- NVS에서 TCP 서버 IP를 읽어오는 함수 ---
String loadTcpIpFromNVS() {
  prefs.begin(NVS_NAMESPACE, true); // Read-only mode
  String ip = prefs.getString(NVS_KEY_TCP_IP, "");
  prefs.end();
  if (ip.length() > 0) {
    uart0_printf("[%8lu ms] [NVS] Loaded TCP Server IP: %s\n", millis(), ip.c_str());
  } else {
    uart0_printf("[%8lu ms] [NVS] No TCP Server IP found in NVS.\n", millis());
  }
  return ip;
}


// --- 설정 모드 (SoftAP) 초기화 함수 ---
void setup_config_mode() {
  startSoftAP();
}

// --- 설정 모드 루프 함수 ---
void loop_config_mode() {
  server.handleClient();
}

#endif // _LIB_OTA_H_