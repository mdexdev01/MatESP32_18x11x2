// lib_config_mode.h
// Version: Ver.1.0
// Author: mdex.co.kr & Refactored by AI
// Date: 2025-07-22
// 역할: SoftAP 기반의 설정 모드를 총괄. WiFi 설정 및 OTA 진입 UI 제공.

#ifndef _LIB_CONFIG_MODE_H_
#define _LIB_CONFIG_MODE_H_

#include <WebServer.h>
#include <Preferences.h>
#include "lib_nvs.h"
#include "lib_ota.h" // OTA 셋업 함수를 호출하기 위해 포함
#include "libPrintRaw.h"

// --- 전역 객체 및 변수 ---
WebServer server(80);
bool shouldEnterSoftAP = false;
extern bool otaUpdateRequested; // network_task.h에 정의될 플래그

// --- 상수 정의 ---
const char* ap_ssid = "LUXTEP_MAT_CONFIG";
const char* ap_password = "password";

// --- 웹 페이지 핸들러 ---
void handleRoot() {
    String html = R"rawliteral(
    <!DOCTYPE html>
    <html>
    <head>
      <title>ESP32 Configuration</title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <style>
        body { font-family: Arial, sans-serif; margin: 20px; background-color: #333; color: #eee; }
        .container { background-color: #555; padding: 20px; border-radius: 8px; max-width: 400px; margin: auto; }
        input[type="text"], input[type="password"] {
          width: calc(100% - 20px); padding: 10px; margin: 8px 0; border: 1px solid #777; border-radius: 4px;
          box-sizing: border-box; background-color: #444; color: #eee;
        }
        input[type="submit"], button {
          width: 100%; background-color: #4CAF50; color: white; padding: 14px 20px; margin: 8px 0;
          border: none; border-radius: 4px; cursor: pointer; font-size: 16px; text-decoration: none; display: inline-block; text-align: center;
        }
        input[type="submit"]:hover, button:hover { background-color: #45a049; }
        .ota-button { background-color: #f44336; }
        .ota-button:hover { background-color: #da190b; }
        label { display: block; margin-bottom: 5px; color: #ccc; }
      </style>
    </head>
    <body>
      <div class="container">
        <h2>WiFi & AppID Configuration</h2>
        <form action="/save" method="POST">
          <label for="ssid">WiFi SSID:</label>
          <input type="text" id="ssid" name="ssid" value="%SSID_VALUE%"><br>
          <label for="password">WiFi Password:</label>
          <input type="password" id="password" name="password" value="%PASS_VALUE%"><br>
          <label for="app_id">AppID:</label>
          <input type="text" id="app_id" name="app_id" value="%APPID_VALUE%"><br>
          <input type="submit" value="Save & Connect">
        </form>
        %OTA_BUTTON%
      </div>
    </body>
    </html>
    )rawliteral";

    prefs.begin(NVS_NAMESPACE, true);
    html.replace("%SSID_VALUE%", prefs.getString(NVS_KEY_SSID, DEFAULT_SSID));
    html.replace("%PASS_VALUE%", prefs.getString(NVS_KEY_PASS, DEFAULT_PASSWORD));
    html.replace("%APPID_VALUE%", prefs.getString(NVS_KEY_APPID, DEFAULT_APPID));
    prefs.end();

    // OTA 모드일 경우에만 펌웨어 업데이트 버튼을 표시
    if (otaUpdateRequested) {
        html.replace("%OTA_BUTTON%", R"rawliteral(<button class="ota-button" onclick="location.href='/update'">Update Firmware</button>)rawliteral");
    } else {
        html.replace("%OTA_BUTTON%", "");
    }

    server.send(200, "text/html", html);
}

void handleSave() {
    prefs.begin(NVS_NAMESPACE, false);
    prefs.putString(NVS_KEY_SSID, server.arg("ssid"));
    prefs.putString(NVS_KEY_PASS, server.arg("password"));
    prefs.putString(NVS_KEY_APPID, server.arg("app_id"));
    prefs.end();

    server.send(200, "text/html", "Saved. Rebooting...");
    delay(1000);
    ESP.restart();
}

// --- 설정 모드 관리 함수 ---
void setup_config_mode() {
    uart0_printf("[%8lu ms] [Config Mode] Starting SoftAP '%s'...\n", millis(), ap_ssid);
    WiFi.softAP(ap_ssid, ap_password);
    IPAddress IP = WiFi.softAPIP();
    uart0_printf("[%8lu ms] [Config Mode] AP IP: %s\n", millis(), IP.toString().c_str());

    server.on("/", HTTP_GET, handleRoot);
    server.on("/save", HTTP_POST, handleSave);

    // "do ota" 명령으로 진입한 경우에만 OTA 관련 핸들러를 추가
    if (otaUpdateRequested) {
        setup_ota(server); // lib_ota.h 에 있는 OTA 셋업 함수 호출
        uart0_printf("[%8lu ms] [Config Mode] OTA Update is enabled. Go to /update\n", millis());
    }

    server.begin();
    uart0_printf("[%8lu ms] [Config Mode] Web server started.\n", millis());
}

void loop_config_mode() {
    server.handleClient();
}

#endif // _LIB_CONFIG_MODE_H_