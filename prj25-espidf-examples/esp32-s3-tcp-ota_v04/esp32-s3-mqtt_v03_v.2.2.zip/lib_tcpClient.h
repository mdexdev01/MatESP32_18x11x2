// lib_tcpClient.h
// Version: Ver.2.2 (Cleaned up)
// Author: mdex.co.kr
// Date: 2025-07-22

#ifndef _LIB_TCPCLIENT_H_
#define _LIB_TCPCLIENT_H_

#include <WiFi.h>
#include "network_info.h"
#include "lib_nvs.h"
#include "libPrintRaw.h"

// --- Extern 변수/객체 선언 ---
extern String storedTcpServerIp;
extern String receivedTcpServerIpAddress;
extern String currentAppID;
extern PubSubClient client; 
extern int board_id_hardcoding; // .ino 파일에 정의된 전역 변수 참조

// --- Extern 함수 선언 ---
void reconnectMqtt();

// --- 변수/객체 정의 ---
WiFiClient tcpClient;
const int TCP_PACKET_SIZE = 998 + 952;
const unsigned long tcpSendInterval = 10;
const unsigned long tcpConnectInterval = 3000;

// --- 함수 구현 ---
void createAndSendTcpPacket() {
    static uint32_t sequenceNumber = 0;
    static uint8_t txBuffer[TCP_PACKET_SIZE];
    txBuffer[0] = 0xFF; txBuffer[1] = 0xFF; txBuffer[2] = 0x02;
    txBuffer[TCP_PACKET_SIZE - 1] = 0xFE;

    // Client ID를 전역 변수 값으로 설정
    txBuffer[3] = board_id_hardcoding;

    if (tcpClient.connected()) {
        txBuffer[TCP_PACKET_SIZE - 2] = sequenceNumber % 100;
        tcpClient.write(txBuffer, TCP_PACKET_SIZE);
    }
    sequenceNumber++;
}

void tcpReceiverTask(void* param) {
    static uint8_t rxBuf[TCP_PACKET_SIZE];
    while (true) {
        if (tcpClient.connected() && TCP_PACKET_SIZE <= tcpClient.available()) {
            tcpClient.read(rxBuf, TCP_PACKET_SIZE);
        }
        delay(1);
    }
}

void loop_checkSafeTCP() {
    static unsigned long lastTcpConnectAttempt = 0;
    
    if (WiFi.status() != WL_CONNECTED) {
        return;
    }

    reconnectMqtt();
    client.loop();

    if (!tcpClient.connected()) {
        if (tcpConnectInterval <= millis() - lastTcpConnectAttempt) {
            if (0 < storedTcpServerIp.length()) {
                if (tcpClient.connect(storedTcpServerIp.c_str(), TCP_SERVER_PORT)) {
                    receivedTcpServerIpAddress = storedTcpServerIp;
                }
            }
            if (!tcpClient.connected() && 0 < receivedTcpServerIpAddress.length()) {
                tcpClient.connect(receivedTcpServerIpAddress.c_str(), TCP_SERVER_PORT);
            }
            lastTcpConnectAttempt = millis();
        }
    }
}

#endif // _LIB_TCPCLIENT_H_
