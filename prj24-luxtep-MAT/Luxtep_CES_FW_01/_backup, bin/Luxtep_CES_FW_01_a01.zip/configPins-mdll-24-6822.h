#ifndef CONFIGPINS_H_
#define CONFIGPINS_H_
#include <Arduino.h>
//   rs485 - rxd, txd, de

//   dip switch - opt 0, 1 [GPIO]
//   OPT0 : MAIN OR SUB
//   OPT1 : NONE

//   dip switch - A 0, 1, 2, 3 [GPIO]
//   SWA0 :

//  LED indicator

//----------------------------------------------------
//  MDLL-24-6822 Pinout
//----------------------------------------------------
//  4067 selection pins
//  Num of Mux output
#define MUX_74HC4067_OUT 16
#define MUX_74HC4067_HALF_OUT 8
#define MUX_74HC4051_OUT 8

#define NUM_MUX_OUT MUX_74HC4051_OUT

#define NUM_REAL_WIDTH 10
#define NUM_REAL_HEIGHT 12
#define NUM_REAL_SENSOR_CH (NUM_REAL_WIDTH * NUM_REAL_HEIGHT)

//-------------------------------------------------------------
//   MUX, POWER[28] - NX3L4051HR power  [S0 ~ S2, Z, EN0~EN3] : EXT0~EXT27,
//  Mux for Ext power - NX3L4051HR
const int NUM_MUX_SIG = 3;
#define pinExtS0 4
#define pinExtS1 5
#define pinExtS2 6
int pinMuxPwrSel[NUM_MUX_SIG] = {pinExtS0, pinExtS1, pinExtS2};

const int NUM_PWR_MUX = 4;
#define pinExtEn0 20
#define pinExtEn1 3
#define pinExtEn2 46
#define pinExtEn3 9
int pinMuxPwrEn[NUM_PWR_MUX] = {pinExtEn0, pinExtEn1, pinExtEn2, pinExtEn3};
int en_ext_mux_id = -1;

//-------------------------------------------------------------
//   MUX, INPUT[34]  - NX3L4051HR input  [AN0~AN2, Z, EN4~EN8] : SEN0~SEN33,, SW-OPT0, 1,, SW-A0~A3
//  Mux for Sensor - NX3L4051HR
#define pinSenS0 42  //  AN0
#define pinSenS1 41  //  AN1
#define pinSenS2 40  //  AAN2
int pinMuxSenSel[NUM_MUX_SIG] = {pinSenS0, pinSenS1, pinSenS2};

const int NUM_SEN_MUX = 5;
#define pinSenEn0 10
#define pinSenEn1 11
#define pinSenEn2 12
#define pinSenEn3 39
#define pinSenEn4 38
int pinMuxSenEn[NUM_SEN_MUX] = {pinSenEn0, pinSenEn1, pinSenEn2, pinSenEn3, pinSenEn4};
int en_sen_mux_id = -1;

//-------------------------------------------------------------
//   adc - aref [ADC]
//   adc - aout [ADC]
#define pinVOut 1  //  ADC1_0
#define pinVRef 2  //  ADC1_1

//  ADC Buffer
#define NUM_PWR 28  // X
#define NUM_SEN 34  // Y

#define NUM_COL NUM_PWR  // X
#define NUM_ROW NUM_SEN  // Y

#define SIZE_X NUM_COL
#define SIZE_Y NUM_ROW

int VOut_Value[NUM_PWR][NUM_SEN];
int VRef_Value[NUM_PWR][NUM_SEN];
int ForceData[NUM_PWR][NUM_SEN];

byte force_buf[SIZE_X * SIZE_Y];
byte inpol_buf[SIZE_X * (SIZE_Y + 1)];  // interpolation buffer

//  Dip Switch

//  HW Pin # - Wakeup, ADC
#define RESOLUTION_BITS (12)  // choose resolution (explained in depth below)

// XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
//-------------------------------------------------------------
//  DIP Switch
#define DIP_SW_NUM 2
bool dip_sw_value[DIP_SW_NUM];
bool dip_sw_value_last[DIP_SW_NUM];
int dip_decimal = 0;

//-------------------------------------------------------------
//   TACT - 1, 2, 3 [GPIO]

//-------------------------------------------------------------
//   BUZZER 1, 2 [PWM]
#define BZ1_CTL 7
#define BZ2_CTL 15

//-------------------------------------------------------------
//  LED strip - DI0~DI3
#define DI0 47
#define DI1 21
#define DI2 14
#define DI3 13
//-----------------------------------------
//  RS485
int pin485U1DE = 19;

///////////////////////////////////////////////////////////////////////////
//    SETUP
///////////////////////////////////////////////////////////////////////////
void setup_HWPins_34x28() {
    analogReadResolution(RESOLUTION_BITS);  // set the resolution of analogRead results
                                            //  - maximum: 14 bits (maximum ADC resolution)
                                            //  - default: 10 bits (standard Arduino setting)
                                            //  - minimum:  1 bit

    // pinMode(LED_BUILTIN, OUTPUT);

    // LED matrix
    pinMode(DI0, OUTPUT);
    pinMode(DI1, OUTPUT);
    pinMode(DI2, OUTPUT);
    pinMode(DI3, OUTPUT);

    pinMode(pinVOut, INPUT);
    pinMode(pinVRef, INPUT);

    for (int i = 0; i < NUM_MUX_SIG; i++) {
        pinMode(pinMuxPwrSel[i], OUTPUT);
        digitalWrite(pinMuxPwrSel[i], LOW);
        // pinMode(pinMuxLatSel[i], OUTPUT);
        // digitalWrite(pinMuxLatSel[i], LOW);
        pinMode(pinMuxSenSel[i], OUTPUT);
        digitalWrite(pinMuxSenSel[i], LOW);
    }

    for (int i = 0; i < NUM_PWR_MUX; i++) {
        pinMode(pinMuxPwrEn[i], OUTPUT);
        digitalWrite(pinMuxPwrEn[i], HIGH);
    }

    for (int i = 0; i < NUM_SEN_MUX; i++) {
        pinMode(pinMuxSenEn[i], OUTPUT);
        digitalWrite(pinMuxSenEn[i], HIGH);
    }

    delay(5);
}

//-----------------------------------------------------
//    READ ADC WITH MUX
//-----------------------------------------------------
int loop_gpio_count = 0;

int muxSig3PinsVal[NUM_MUX_OUT][NUM_MUX_SIG] = {
    // [Mux Output : 0~7][Signal Pin : 0~2]
    //  {S0,S1,S2}
    {0, 0, 0},  // channel 0
    {1, 0, 0},  // channel 1
    {0, 1, 0},  // channel 2
    {1, 1, 0},  // channel 3   It means S0=1, S1=1, S2=0
    {0, 0, 1},  // channel 4
    {1, 0, 1},  // channel 5
    {0, 1, 1},  // channel 6
    {1, 1, 1},  // channel 7
};

//-----------------------------------------------------
//    MUX WORKING - EXT
//-----------------------------------------------------
void selectExtMux(int ext_mux_id) {
    if (en_ext_mux_id == ext_mux_id)
        return;

    for (int i = 0; i < NUM_PWR_MUX; i++) {
        digitalWrite(pinMuxPwrEn[i], HIGH);
    }

    digitalWrite(pinMuxPwrEn[ext_mux_id], LOW);
    // digitalWrite(pinLatEn0, LOW);

    en_ext_mux_id = ext_mux_id;
}

void select1ExtchInExtMux(int ext_ch) {
    // config signal 4 pins
    for (int i = 0; i < NUM_MUX_SIG; i++) {
        digitalWrite(pinMuxPwrSel[i], muxSig3PinsVal[ext_ch][i]);
    }
}

void selectPwrCh(int pwr_ch) {
    int mux_id = pwr_ch / MUX_74HC4051_OUT;
    int mux_out = pwr_ch % MUX_74HC4051_OUT;
    selectExtMux(mux_id);
    select1ExtchInExtMux(mux_out);
}

//-----------------------------------------------------
//    MUX WORKING - SENSOR
//-----------------------------------------------------
void selectSenMux(int sen_mux_id) {
    if (en_sen_mux_id == sen_mux_id)
        return;

    for (int i = 0; i < NUM_SEN_MUX; i++) {
        digitalWrite(pinMuxSenEn[i], HIGH);
    }

    digitalWrite(pinMuxSenEn[sen_mux_id], LOW);

    en_sen_mux_id = sen_mux_id;
}

int _vout_raw;
int _vref_raw;
int read1chInSenMux(int mux_ch) {
    // config signal 4 pins
    for (int i = 0; i < NUM_MUX_SIG; i++) {
        digitalWrite(pinMuxSenSel[i], muxSig3PinsVal[mux_ch][i]);
    }

    _vout_raw = analogRead(pinVOut);
    _vref_raw = analogRead(pinVRef);

    return _vout_raw;
}

//  8ch Mux IC 74HC4051 OR Half of 74HC4067
void read8chInSenMux(int ext_ch) {
    for (int i = 0; i < NUM_MUX_OUT; i++) {
        read1chInSenMux(i);
        VOut_Value[ext_ch][i] = _vout_raw;
        VRef_Value[ext_ch][i] = _vref_raw;
    }
}

void readSenCh(int sen_ch) {
    int mux_id = sen_ch / MUX_74HC4051_OUT;
    int mux_out = sen_ch % MUX_74HC4051_OUT;
    selectSenMux(mux_id);
    read1chInSenMux(mux_out);
}

#endif  // CONFIGPINS_H_